# Automatic-MCQ-Grader
Automatic MCQ Grader using classical algorithms
